﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZedGraph;
using System.IO.Ports;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;




namespace uart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        string[] baud = { "1200", "2400", "4800", "9600", "14400", "19200", "38400", "56000", "57600", "115200" };
        string[] databit = { "5", "6", "7", "8" };
        


        private void Form1_Load(object sender, EventArgs e)
        {
            // Đồ thị
            GraphPane mypanne = zedGraphControl1.GraphPane;
            mypanne.Title.Text = "NHÓM 03 ";
            mypanne.XAxis.Title.Text = "Thời gian";
            mypanne.YAxis.Title.Text = "Giá trị (°C)";
            RollingPointPairList list = new RollingPointPairList(60000);
            LineItem duongline = mypanne.AddCurve("Nhiệt độ", list, Color.Red, SymbolType.None);
            



            mypanne.XAxis.Scale.Min = 0;
            mypanne.XAxis.Scale.Max = 100;
            mypanne.XAxis.Scale.MinorStep = 1;
            mypanne.XAxis.Scale.MajorStep = 5;


            mypanne.YAxis.Scale.Min = 0;
            mypanne.YAxis.Scale.Max = 100;
            mypanne.YAxis.Scale.MinorStep = 1;
            mypanne.YAxis.Scale.MajorStep = 5;
            zedGraphControl1.AxisChange();

            string[] myport = SerialPort.GetPortNames();
            comboBox1.Items.AddRange(myport);
            comboBox2.Items.AddRange(baud);
        }
        int tong = 0;
    public void draw(double line)
        {
            LineItem duongline = zedGraphControl1.GraphPane.CurveList[0] as LineItem;
            if (duongline == null)  
                return;
            IPointListEdit list = duongline.Points as IPointListEdit;
            if(list == null)    
                return ;
            list.Add(tong,line);
            zedGraphControl1.AxisChange();
            zedGraphControl1.Invalidate();
            tong += 2;

        }

       

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();
                btnConnect.Enabled = true;
                btnDisconnect.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName = comboBox1.Text;
                serialPort1.BaudRate = int.Parse(comboBox2.Text);
               
                serialPort1.Open();
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = true;



            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());

            }
        }
        //string data = "";

        // Biến để lưu trữ min, max và avg nhiệt độ
        double minTemperature = double.MaxValue;
        double maxTemperature = double.MinValue;
        double sumTemperature = 0;
        int count = 0;

        // Hàm cập nhật min, max và avg nhiệt độ
        private void UpdateMinMaxAvgTemperature(int temperature)
        {
            minTemperature = Math.Min(minTemperature, temperature);
            maxTemperature = Math.Max(maxTemperature, temperature);
            sumTemperature += temperature;
            count++;

            btmin.Text = minTemperature.ToString(); // Hiển thị min nhiệt độ
            btmax.Text = maxTemperature.ToString(); // Hiển thị max nhiệt độ
            btavg.Text = (sumTemperature / count).ToString(); // Hiển thị avg nhiệt độ
        }

        private void ProcessData(string data)
        {
            if (data.StartsWith("a"))
            {
                string count = data.Substring(1); // Extract the interrupt count
                btdem.Text = count; // Display interrupt count
            }
            else if (data.StartsWith("b"))
            {
                string temperature = data.Substring(1); // Extract the temperature
                listBox1.Items.Add(temperature); // Add temperature to the listbox
                draw(int.Parse(temperature));
                UpdateMinMaxAvgTemperature(int.Parse(temperature)); // Cập nhật min, max và avg nhiệt độ
            }
            else
            {
                // Handle other types of data if needed
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //data += serialPort1.ReadExisting();
            ////Invoke(new MethodInvoker(() => listBox1.Items.Add(data)));
            //if (data.Length >2)
            //{
            //   //Invoke(new MethodInvoker(() => listBox1.Items.Add(data)));
            //  // Invoke(new MethodInvoker(() => draw(int.Parse(data))));
            //    data = "";
            //}
            string receivedData = serialPort1.ReadLine().ToString();

            try
            {
                BeginInvoke(new Action(() =>
                {
                    //btdem.Text = count.ToString();
                    //listBox1.Items.Add(count);
                    //draw(int.Parse(count));
                    ProcessData(receivedData);
                }));
            }
            catch
            {

            }

        }

        private void Send_Click(object sender, EventArgs e)
        {
            serialPort1.Write(textBox1.Text);

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        bool tb1 = true;
        private void led1_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true)
            //{
            //    //serialPort1.Close();
            //    led1.Text = "ON";
            //    //led1.BackColor = Color.White;
            //    serialPort1.Write("q");
            //    serialPort1.Close();
            //}
            //else if(serialPort1.IsOpen == false)
            //{
            //    serialPort1.Open();
            //    serialPort1.Write("a");
            //    led1.Text = "OFF";
            //    //led1.BackColor = Color.BlueViolet;
            //    //serialPort1.Write("1");
            //}
            try
            {
                if (tb1 == true)
                {
                    serialPort1.Write("q");
                    led1.Text = "OFF";
                    led1.BackColor = Color.Red;
                    tb1 = false;
                }
                else
                {
                    serialPort1.Write("a");
                    led1.Text = "ON";
                    led1.BackColor = Color.White;
                    tb1 = true;
                }
            }
            catch
            {
                MessageBox.Show("LOI");
            }
        }

        bool tb2 = true;
        private void led2_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true)
            //{
            //    //serialPort1.Close();
            //    led2.Text = "ON";
            //    //led2.BackColor = Color.White;
            //    serialPort1.Write("w");
            //    serialPort1.Close();
            //}
            //else if (serialPort1.IsOpen == false)
            //{
            //    serialPort1.Open();
            //    serialPort1.Write("s");
            //    led2.Text = "OFF";
            //    //led2.BackColor = Color.BlueViolet;
            //    //serialPort1.Write("1");
            //}
            try
            {
                if (tb2 == true)
                {
                    serialPort1.Write("w");
                    led2.Text = "OFF";
                    led2.BackColor = Color.Yellow;
                    tb2 = false;
                }
                else
                {
                    serialPort1.Write("s");
                    led2.Text = "ON";
                    led2.BackColor = Color.White;
                    tb2 = true;
                }
            }
            catch
            {
                MessageBox.Show("LOI");
            }
        }

        bool tb3 = true;
        private void led3_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true)
            //{
            //    //serialPort1.Close();
            //    led3.Text = "ON";
            //    //led3.BackColor = Color.White;
            //    serialPort1.Write("e");
            //    serialPort1.Close();
            //}
            //else if (serialPort1.IsOpen == false)
            //{
            //    serialPort1.Open();
            //    serialPort1.Write("d");
            //    led3.Text = "OFF";
            //    //led3.BackColor = Color.BlueViolet;
            //    //serialPort1.Write("1");
            //}
            try
            {
                if (tb3 == true)
                {
                    serialPort1.Write("e");
                    led3.Text = "OFF";
                    led3.BackColor = Color.Green;
                    tb3 = false;
                }
                else
                {
                    serialPort1.Write("d");
                    led3.Text = "ON";
                    led3.BackColor = Color.White;
                    tb3 = true;
                }
            }
            catch
            {
                MessageBox.Show("LOI");
            }
        }

        bool tb4 = true;
        private void led4_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true)
            //{
            //    //serialPort1.Close();
            //    led4.Text = "ON";
            //    //led4.BackColor = Color.White;
            //    serialPort1.Write("r");
            //    serialPort1.Close();
            //}
            //else if (serialPort1.IsOpen == false)
            //{
            //    serialPort1.Open();
            //    serialPort1.Write("f");
            //    led4.Text = "OFF";
            //    //led4.BackColor = Color.BlueViolet;
            //    //serialPort1.Write("1");
            //}
            try
            {
                if (tb4 == true)
                {
                    serialPort1.Write("r");
                    led4.Text = "OFF";
                    led4.BackColor = Color.Pink;
                    tb4 = false;
                }
                else
                {
                    serialPort1.Write("f");
                    led4.Text = "ON";
                    led4.BackColor = Color.White;
                    tb4 = true;
                }
            }
            catch
            {
                MessageBox.Show("LOI");
            }
        }

        bool tb5 = true;
        private void led5_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true)
            //{
            //    //serialPort1.Close();
            //    led5.Text = "ON";
            //    //led5.BackColor = Color.White;
            //    serialPort1.Write("t");
            //    serialPort1.Close();
            //}
            //else if (serialPort1.IsOpen == false)
            //{
            //    serialPort1.Open();
            //    serialPort1.Write("g");
            //    led5.Text = "OFF";
            //    //led5.BackColor = Color.BlueViolet;
            //    //serialPort1.Write("1");
            //}
            try
            {
                if (tb5 == true)
                {
                    serialPort1.Write("t");
                    led5.Text = "OFF";
                    led5.BackColor = Color.Red;
                    tb5 = false;
                }
                else
                {
                    serialPort1.Write("g");
                    led5.Text = "ON";
                    led5.BackColor = Color.White;
                    tb5 = true;
                }
            }
            catch
            {
                MessageBox.Show("LOI");
            }
        }

        bool tb6 = true;
        private void led6_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true)
            //{
            //    //serialPort1.Close();
            //    led6.Text = "ON";
            //    //led6.BackColor = Color.White;
            //    serialPort1.Write("y");
            //    serialPort1.Close();
            //}
            //else if (serialPort1.IsOpen == false)
            //{
            //    serialPort1.Open();
            //    serialPort1.Write("h");
            //    led6.Text = "OFF";
            //    //led6.BackColor = Color.BlueViolet;
            //    //serialPort1.Write("1");
            //}
            try
            {
                if (tb6 == true)
                {
                    serialPort1.Write("y");
                    led6.Text = "OFF";
                    led6.BackColor = Color.Yellow;
                    tb6 = false;
                }
                else
                {
                    serialPort1.Write("h");
                    led6.Text = "ON";
                    led6.BackColor = Color.White;
                    tb6 = true;
                }
            }
            catch
            {
                MessageBox.Show("LOI");
            }
        }

        bool tb7 = true;
        private void led7_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true)
            //{
            //    //serialPort1.Close();
            //    led7.Text = "ON";
            //    //led7.BackColor = Color.White;
            //    serialPort1.Write("u");
            //    serialPort1.Close();
            //}
            //else if (serialPort1.IsOpen == false)
            //{
            //    serialPort1.Open();
            //    serialPort1.Write("j");
            //    led7.Text = "OFF";
            //    //led7.BackColor = Color.BlueViolet;
            //    //serialPort1.Write("1");
            //}
            try
            {
                if (tb7 == true)
                {
                    serialPort1.Write("u");
                    led7.Text = "OFF";
                    led7.BackColor = Color.Green;
                    tb7 = false;
                }
                else
                {
                    serialPort1.Write("j");
                    led7.Text = "ON";
                    led7.BackColor = Color.White;
                    tb7 = true;
                }
            }
            catch
            {
                MessageBox.Show("LOI");
            }
        }

        bool tb8 = true;
        private void led8_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true)
            //{
            //    //serialPort1.Close();
            //    led8.Text = "ON";
            //    //led8.BackColor = Color.White;
            //    serialPort1.Write("i");
            //    serialPort1.Close();
            //}
            //else if (serialPort1.IsOpen == false)
            //{
            //    serialPort1.Open();
            //    serialPort1.Write("k");
            //    led8.Text = "OFF";
            //    //led8.BackColor = Color.BlueViolet;
            //    //serialPort1.Write("1");
            //}
            try
            {
                if (tb8 == true)
                {
                    serialPort1.Write("i");
                    led8.Text = "OFF";
                    led8.BackColor = Color.Pink;
                    tb8 = false;
                }
                else
                {
                    serialPort1.Write("k");
                    led8.Text = "ON";
                    led8.BackColor = Color.White;
                    tb8 = true;
                }
            }
            catch
            {
                MessageBox.Show("LOI");
            }
        }

        private void Receieve_Click(object sender, EventArgs e)
        {

        }


        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        bool tb9 = true;
        private void button1_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true)
            //{
            //    //serialPort1.Close();
            //    button1.Text = "ON";
            //    button1.BackColor = Color.Red;
            //    serialPort1.Write("o");
            //    serialPort1.Close();
            //}
            //else if (serialPort1.IsOpen == false)
            //{
            //    serialPort1.Open();
            //    serialPort1.Write("f");
            //    button1.Text = "OFF";
            //    button1.BackColor = Color.DarkOliveGreen;
            //    //serialPort1.Write("1");
            //}
            try
            {
                if (tb9 == true)
                {
                    serialPort1.Write("o");
                    button1.Text = "OFF";
                    button1.BackColor = Color.Aqua;
                    tb9 = false;

                    led1.Text = "OFF";
                    led2.Text = "OFF";
                    led3.Text = "OFF";
                    led4.Text = "OFF";
                    led5.Text = "OFF";
                    led6.Text = "OFF";
                    led7.Text = "OFF";
                    led8.Text = "OFF";

                    led1.BackColor = Color.Red;
                    led2.BackColor = Color.Yellow;
                    led3.BackColor = Color.Green;
                    led4.BackColor = Color.Pink;
                    led5.BackColor = Color.Red;
                    led6.BackColor = Color.Yellow;
                    led7.BackColor = Color.Green;
                    led8.BackColor = Color.Pink;
                }
                else
                {
                    serialPort1.Write("l");
                    button1.Text = "ON";
                    button1.BackColor = Color.White;
                    tb9 = true;

                    led1.Text = "ON";
                    led2.Text = "ON";
                    led3.Text = "ON";
                    led4.Text = "ON";
                    led5.Text = "ON";
                    led6.Text = "ON";
                    led7.Text = "ON";
                    led8.Text = "ON";

                    led1.BackColor = Color.White;
                    led2.BackColor = Color.White;
                    led3.BackColor = Color.White;
                    led4.BackColor = Color.White;
                    led5.BackColor = Color.White;
                    led6.BackColor = Color.White;
                    led7.BackColor = Color.White;
                    led8.BackColor = Color.White;
                }
            }
            catch
            {
                MessageBox.Show("LOI");
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void zedGraphControl1_Load(object sender, EventArgs e)
        {

        }
    }
}
